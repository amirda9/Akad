<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CouponUseage extends Model
{
    protected $table = "coupon_useage";
    protected $guarded = [];
}
