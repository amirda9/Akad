<?php


namespace App\Charts;


use App\Order;

class Dataset
{

    public $label = '';
    public $data = [];
    public $backgroundColor = [];
    public $borderColor = [];
    public $borderWidth = 1;


}
