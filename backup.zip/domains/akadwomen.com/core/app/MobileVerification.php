<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MobileVerification extends Model
{
    protected $table = 'mobile_verifications';
    protected $guarded = [];
}
