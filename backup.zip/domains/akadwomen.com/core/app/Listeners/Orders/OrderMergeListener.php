<?php

namespace App\Listeners\Orders;

use App\Events\Orders\OrderMerged;
use App\Events\Orders\OrderPaid;
use App\Variation;

class OrderMergeListener
{
    public function __construct()
    {
        //
    }

    public function handle(OrderMerged $event)
    {
        $order = $event->order;
        if($order->items()->where('is_paid',false)->orWhereNull('is_paid')->count()) {
            $order->update([
                'is_paid' => false
            ]);
        }
    }
}
