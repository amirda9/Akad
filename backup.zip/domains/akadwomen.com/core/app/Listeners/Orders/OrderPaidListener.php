<?php

namespace App\Listeners\Orders;

use App\Events\Orders\OrderPaid;
use App\Variation;

class OrderPaidListener
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  OrderPaid  $event
     * @return void
     */
    public function handle(OrderPaid $event)
    {
        $order = $event->order;
        foreach ($order->items as $item) {
            if (!$item->is_paid) {
                $product = $item->product;
                if ($product) {
                    if ($product->isSimple()) {
                        $product->update([
                            'stock' => $product->stock - $item->quantity
                        ]);
                    }
                    if ($product->isVariable()) {
                        $variation = Variation::where('id', $item->variation_id)->first();
                        if ($variation) {
                            $variation->update([
                                'stock' => $variation->stock - $item->quantity
                            ]);
                        }
                    }
                }
            }
        }
        $order->items()->update([
            'is_paid' => true
        ]);

        $order->update([
            'received_money' => $order->getFinalPrice(),
            'is_paid' => true,
            'status' => 'processing'
        ]);
    }
}
