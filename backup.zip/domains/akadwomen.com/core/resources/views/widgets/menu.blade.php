<ul id="main_menu" class="d-none d-lg-flex ml-auto flex-wrap flex-grow-1">
    @include('other.main_menu_items',[
        'items' => $items
    ])
</ul>