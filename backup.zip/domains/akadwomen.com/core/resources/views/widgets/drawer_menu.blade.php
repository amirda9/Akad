<ul id="drawer_menu">
    @include('other.drawer_menu_items',[
        'items' => $items
    ])
</ul>