<div id="drawer">
    <a href="javascript:void(0)" class="close-btn">&times;</a>
    @widget('drawer_menu',['name' => 'mainmenu'])
</div>