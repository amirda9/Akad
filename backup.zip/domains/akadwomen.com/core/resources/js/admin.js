require('./bootstrap-admin');
require('../../node_modules/bootstrap-select/dist/js/bootstrap-select.min');
require('../../node_modules/bootstrap-select/dist/js/i18n/defaults-fa_IR.min');
